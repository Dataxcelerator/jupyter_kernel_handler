# Jupyter Printer

Jupyter Notebook Cell Execution Monitor with colored output for cell execution events.

## Features
- Pre-run cell content display (blue)
- Real-time output (green)
- Post-run summary (yellow)

## Usage
```python
import jupyter_printer
jupyter_printer.activate()
```

## License
MIT
